for x in range(1,1001):
    if x%2 == 0:
        print(x)

